Hello! Thank you for taking interest in my font, 8-bit Madness. This font should be found only at www.dafont.com, if it is found anywhere else, please contact me at robotdude@att.net.

This font is free for personal use, however if you plan to use it commercially, send me an email at the address listed above to discuss possible pricing.

Enjoy, and game on! :)